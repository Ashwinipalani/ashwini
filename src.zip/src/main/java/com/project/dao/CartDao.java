package com.project.dao;
import com.project.model.*;
public interface CartDao {
	Cart getCart(int cartId);
}
