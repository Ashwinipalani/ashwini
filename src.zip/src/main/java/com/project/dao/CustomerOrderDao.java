package com.project.dao;

import com.project.model.Cart;

public interface CustomerOrderDao {
void addCustomerOrder(Cart cart);
}
