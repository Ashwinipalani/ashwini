 package com.project.dao;
import java.util.List;

import com.project.model.Category;

public interface CategoryDao {
	List<Category> getCategories();	

}

