package com.project.service;
import com.project.model.*;

public interface CartService {
	Cart getCart(int cartId);
}
