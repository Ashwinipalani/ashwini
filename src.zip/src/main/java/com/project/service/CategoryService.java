package com.project.service;

import java.util.List;

import com.project.model.Category;

public interface CategoryService {
	List<Category> getCategories();

}

